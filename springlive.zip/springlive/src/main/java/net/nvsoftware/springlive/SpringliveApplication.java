package net.nvsoftware.springlive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringliveApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringliveApplication.class, args);
	}

}
